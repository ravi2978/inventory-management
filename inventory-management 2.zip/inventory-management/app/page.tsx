import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

export default function LoginPage() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-green-gradient">
      <div className="w-full max-w-md p-8 space-y-8 bg-white rounded-lg shadow-lg">
        <div className="flex flex-col items-center justify-center text-center">
          <div className="relative w-32 h-32 mb-4">
            <Image src="/logo.svg" alt="Inventory Management Logo" fill className="object-contain" priority />
          </div>
          <h2 className="text-2xl font-bold text-dark-green">Profit Maximizer</h2>
          <p className="mt-2 text-sm text-gray-600">Inventory Management System</p>
        </div>

        <form className="mt-8 space-y-6">
          <div className="space-y-4">
            <div>
              <label htmlFor="username" className="block text-sm font-medium text-gray-700">
                Username
              </label>
              <Input
                id="username"
                name="username"
                type="text"
                required
                className="mt-1"
                placeholder="Enter your username"
              />
            </div>

            <div>
              <label htmlFor="password" className="block text-sm font-medium text-gray-700">
                Password
              </label>
              <Input
                id="password"
                name="password"
                type="password"
                required
                className="mt-1"
                placeholder="Enter your password"
              />
            </div>
          </div>

          <div>
            <Link href="/dashboard">
              <Button className="w-full bg-dark-green hover:bg-dark-green/90" size="lg">
                Login
              </Button>
            </Link>
          </div>
        </form>
      </div>
    </div>
  )
}

