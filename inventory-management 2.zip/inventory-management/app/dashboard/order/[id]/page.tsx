import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Check, ArrowLeft, Printer, Download } from "lucide-react"
import Link from "next/link"

export default function OrderDetailPage({ params }: { params: { id: string } }) {
  // Sample order data
  const order = {
    id: params.id,
    customer: "John Smith",
    email: "john.smith@example.com",
    phone: "(555) 123-4567",
    date: "2023-05-15",
    status: "Completed",
    items: [
      { id: "ITEM-001", name: "Wireless Keyboard", quantity: 1, price: "$59.99" },
      { id: "ITEM-002", name: "Wireless Mouse", quantity: 1, price: "$39.99" },
      { id: "ITEM-003", name: "Monitor Stand", quantity: 1, price: "$49.99" },
    ],
    subtotal: "$149.97",
    tax: "$7.02",
    total: "$156.99",
    shippingAddress: {
      street: "123 Main St",
      city: "Chicago",
      state: "IL",
      zip: "60601",
    },
    distributionCenter: "Central DC",
    deliveryDate: "2023-05-20",
    trackingNumber: "TRK12345678",
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Link href="/dashboard/orders">
          <Button variant="outline" size="icon">
            <ArrowLeft className="h-4 w-4" />
          </Button>
        </Link>
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Order #{params.id}</h1>
          <p className="text-muted-foreground">View and manage order details</p>
        </div>
        <div className="ml-auto flex gap-2">
          <Button variant="outline" size="sm">
            <Printer className="mr-2 h-4 w-4" />
            Print
          </Button>
          <Button variant="outline" size="sm">
            <Download className="mr-2 h-4 w-4" />
            Download
          </Button>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Order Information</CardTitle>
          </CardHeader>
          <CardContent>
            <dl className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <dt className="font-medium text-gray-500">Order ID</dt>
                <dd>{order.id}</dd>
              </div>
              <div>
                <dt className="font-medium text-gray-500">Date Placed</dt>
                <dd>{order.date}</dd>
              </div>
              <div>
                <dt className="font-medium text-gray-500">Status</dt>
                <dd>
                  <Badge variant="success" className="flex w-fit items-center gap-1">
                    <Check className="h-3 w-3" />
                    {order.status}
                  </Badge>
                </dd>
              </div>
              <div>
                <dt className="font-medium text-gray-500">Distribution Center</dt>
                <dd>{order.distributionCenter}</dd>
              </div>
              <div>
                <dt className="font-medium text-gray-500">Delivery Date</dt>
                <dd>{order.deliveryDate}</dd>
              </div>
              <div>
                <dt className="font-medium text-gray-500">Tracking Number</dt>
                <dd>{order.trackingNumber}</dd>
              </div>
            </dl>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Customer Information</CardTitle>
          </CardHeader>
          <CardContent>
            <dl className="grid gap-4 text-sm">
              <div>
                <dt className="font-medium text-gray-500">Name</dt>
                <dd>{order.customer}</dd>
              </div>
              <div>
                <dt className="font-medium text-gray-500">Email</dt>
                <dd>{order.email}</dd>
              </div>
              <div>
                <dt className="font-medium text-gray-500">Phone</dt>
                <dd>{order.phone}</dd>
              </div>
              <div>
                <dt className="font-medium text-gray-500">Shipping Address</dt>
                <dd>
                  {order.shippingAddress.street}
                  <br />
                  {order.shippingAddress.city}, {order.shippingAddress.state} {order.shippingAddress.zip}
                </dd>
              </div>
            </dl>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Order Items</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <table className="min-w-full divide-y divide-gray-200">
              <thead>
                <tr>
                  <th className="px-6 py-3 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Item
                  </th>
                  <th className="px-6 py-3 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Quantity
                  </th>
                  <th className="px-6 py-3 bg-gray-50 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Price
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {order.items.map((item) => (
                  <tr key={item.id}>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{item.name}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{item.quantity}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 text-right">{item.price}</td>
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr>
                  <td colSpan={2} className="px-6 py-4 text-sm font-medium text-gray-900 text-right">
                    Subtotal
                  </td>
                  <td className="px-6 py-4 text-sm font-medium text-gray-900 text-right">{order.subtotal}</td>
                </tr>
                <tr>
                  <td colSpan={2} className="px-6 py-4 text-sm font-medium text-gray-900 text-right">
                    Tax
                  </td>
                  <td className="px-6 py-4 text-sm font-medium text-gray-900 text-right">{order.tax}</td>
                </tr>
                <tr>
                  <td colSpan={2} className="px-6 py-4 text-sm font-bold text-gray-900 text-right">
                    Total
                  </td>
                  <td className="px-6 py-4 text-sm font-bold text-gray-900 text-right">{order.total}</td>
                </tr>
              </tfoot>
            </table>
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-end gap-4">
        <Button variant="outline">Cancel Order</Button>
        <Button>Update Order</Button>
      </div>
    </div>
  )
}

