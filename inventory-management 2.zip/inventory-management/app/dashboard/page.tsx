import { Button } from "@/components/ui/button"
import { Check, X } from "lucide-react"

export default function Dashboard() {
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-xl font-semibold text-dark-green">Item Requests</h1>
        <div className="flex space-x-2">
          <Button variant="outline" className="bg-white text-dark-green border-medium-green">
            Export to Excel
          </Button>
          <Button variant="outline" className="bg-white text-dark-green border-medium-green">
            Filter
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-light-green rounded-md p-4">
          <h2 className="font-semibold text-dark-green mb-2">New Requests</h2>
          <div className="space-y-3">
            <RequestCard
              name="John Doe"
              role="Sales Manager"
              department="Sales"
              date="12/05/2023"
              items={["Laptop", "Mouse", "Keyboard"]}
            />
            <RequestCard
              name="Jane Smith"
              role="Marketing Lead"
              department="Marketing"
              date="11/05/2023"
              items={["Projector", "Whiteboard"]}
            />
            <RequestCard
              name="Robert Brown"
              role="Developer"
              department="IT"
              date="10/05/2023"
              items={["Monitor", "Headphones"]}
            />
          </div>
        </div>

        <div className="col-span-2">
          <div className="bg-white rounded-md p-4">
            <div className="flex justify-between items-center mb-4">
              <div className="flex space-x-4">
                <Button variant="green" className="rounded-full px-6">
                  Orders
                </Button>
                <Button variant="outline" className="rounded-full px-6 bg-white">
                  Returns
                </Button>
                <Button variant="outline" className="rounded-full px-6 bg-white">
                  Damaged
                </Button>
                <Button variant="outline" className="rounded-full px-6 bg-white">
                  Expired
                </Button>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="min-w-full">
                <thead>
                  <tr className="bg-medium-green text-dark-green">
                    <th className="py-2 px-4 text-left">Order ID</th>
                    <th className="py-2 px-4 text-left">Customer Name</th>
                    <th className="py-2 px-4 text-left">Delivery Date</th>
                    <th className="py-2 px-4 text-left">Delivery Time</th>
                    <th className="py-2 px-4 text-left">Distribution Center</th>
                    <th className="py-2 px-4 text-left">City</th>
                  </tr>
                </thead>
                <tbody>
                  <OrderRow
                    id="ORD-001"
                    customer="John Smith"
                    date="05/15/2023"
                    time="10:30 AM"
                    center="Central DC"
                    city="Chicago"
                    status="completed"
                  />
                  <OrderRow
                    id="ORD-002"
                    customer="Sarah Johnson"
                    date="05/16/2023"
                    time="2:15 PM"
                    center="North DC"
                    city="Minneapolis"
                    status="pending"
                  />
                  <OrderRow
                    id="ORD-003"
                    customer="Michael Brown"
                    date="05/16/2023"
                    time="11:45 AM"
                    center="East DC"
                    city="Boston"
                    status="processing"
                  />
                  <OrderRow
                    id="ORD-004"
                    customer="Emily Davis"
                    date="05/17/2023"
                    time="9:00 AM"
                    center="West DC"
                    city="Seattle"
                    status="completed"
                  />
                  <OrderRow
                    id="ORD-005"
                    customer="Robert Wilson"
                    date="05/17/2023"
                    time="3:30 PM"
                    center="South DC"
                    city="Atlanta"
                    status="pending"
                  />
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="col-span-1">
          <OrderDetailCard
            id="ORD-001"
            date="05/15/2023"
            time="10:30 AM"
            items={[
              { name: "Item 1", quantity: 2, price: "$25.99" },
              { name: "Item 2", quantity: 1, price: "$15.50" },
            ]}
            total="$67.48"
          />
        </div>

        <div className="col-span-2">
          <div className="grid grid-cols-2 gap-4">
            <DistributionCenterCard
              name="Distribution Center"
              location="Chicago, IL"
              status="Active"
              manager="John Anderson"
            />
            <div className="grid grid-cols-1 gap-4">
              <InfoCard label="City" value="Chicago" />
              <InfoCard label="Delivery Date" value="05/15/2023" />
            </div>
          </div>

          <div className="mt-4 bg-white rounded-md p-4">
            <h2 className="font-semibold text-dark-green mb-2">Add Verification</h2>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <div className="flex items-center space-x-2 mb-2">
                  <Check className="h-4 w-4 text-green-500" />
                  <span>Verified</span>
                </div>
                <div className="flex items-center space-x-2 mb-2">
                  <Check className="h-4 w-4 text-green-500" />
                  <span>Completed</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Check className="h-4 w-4 text-green-500" />
                  <span>Delivered</span>
                </div>
              </div>
              <div className="flex justify-end items-end">
                <Button>Add Verification</Button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-white rounded-md p-4">
          <div className="flex justify-between items-center mb-4">
            <h2 className="font-semibold text-dark-green">Distribution FDC</h2>
            <div className="flex space-x-2">
              <Button variant="outline" className="bg-white text-dark-green border-medium-green">
                Export to Excel
              </Button>
              <Button variant="outline" className="bg-white text-dark-green border-medium-green">
                Filter
              </Button>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="min-w-full">
              <thead>
                <tr className="bg-medium-green text-dark-green">
                  <th className="py-2 px-4 text-left">Order ID</th>
                  <th className="py-2 px-4 text-left">Delivery Date</th>
                  <th className="py-2 px-4 text-left">Status</th>
                  <th className="py-2 px-4 text-left">Country</th>
                </tr>
              </thead>
              <tbody>
                <tr className="border-b">
                  <td className="py-2 px-4">ORD-001</td>
                  <td className="py-2 px-4">05/15/2023</td>
                  <td className="py-2 px-4">
                    <span className="bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs">Completed</span>
                  </td>
                  <td className="py-2 px-4">USA</td>
                </tr>
                <tr className="border-b">
                  <td className="py-2 px-4">ORD-002</td>
                  <td className="py-2 px-4">05/16/2023</td>
                  <td className="py-2 px-4">
                    <span className="bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full text-xs">Pending</span>
                  </td>
                  <td className="py-2 px-4">USA</td>
                </tr>
                <tr className="border-b">
                  <td className="py-2 px-4">ORD-003</td>
                  <td className="py-2 px-4">05/16/2023</td>
                  <td className="py-2 px-4">
                    <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded-full text-xs">Processing</span>
                  </td>
                  <td className="py-2 px-4">Canada</td>
                </tr>
              </tbody>
            </table>
          </div>

          <div className="mt-4 bg-light-green rounded-md p-4">
            <h2 className="font-semibold text-dark-green mb-2">Add Verification</h2>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <div className="flex items-center space-x-2 mb-2">
                  <Check className="h-4 w-4 text-green-500" />
                  <span>Verified</span>
                </div>
                <div className="flex items-center space-x-2 mb-2">
                  <Check className="h-4 w-4 text-green-500" />
                  <span>Completed</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Check className="h-4 w-4 text-green-500" />
                  <span>Delivered</span>
                </div>
              </div>
              <div className="flex justify-end items-end">
                <Button>Add Verification</Button>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-md p-4">
          <div className="flex justify-between items-center mb-4">
            <h2 className="font-semibold text-dark-green">Distribution FDC</h2>
            <div className="flex space-x-2">
              <Button variant="outline" className="bg-white text-dark-green border-medium-green">
                Export to Excel
              </Button>
              <Button variant="outline" className="bg-white text-dark-green border-medium-green">
                Filter
              </Button>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="min-w-full">
              <thead>
                <tr className="bg-medium-green text-dark-green">
                  <th className="py-2 px-4 text-left">Order ID</th>
                  <th className="py-2 px-4 text-left">Delivery Date</th>
                  <th className="py-2 px-4 text-left">FDC Status</th>
                  <th className="py-2 px-4 text-left">City</th>
                  <th className="py-2 px-4 text-left">Actions</th>
                </tr>
              </thead>
              <tbody>
                <tr className="border-b">
                  <td className="py-2 px-4">ORD-001</td>
                  <td className="py-2 px-4">05/15/2023</td>
                  <td className="py-2 px-4">
                    <span className="bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs">Completed</span>
                  </td>
                  <td className="py-2 px-4">Chicago</td>
                  <td className="py-2 px-4">
                    <Button variant="green" size="sm">
                      View
                    </Button>
                  </td>
                </tr>
                <tr className="border-b">
                  <td className="py-2 px-4">ORD-002</td>
                  <td className="py-2 px-4">05/16/2023</td>
                  <td className="py-2 px-4">
                    <span className="bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full text-xs">Pending</span>
                  </td>
                  <td className="py-2 px-4">Minneapolis</td>
                  <td className="py-2 px-4">
                    <Button variant="green" size="sm">
                      View
                    </Button>
                  </td>
                </tr>
                <tr className="border-b">
                  <td className="py-2 px-4">ORD-003</td>
                  <td className="py-2 px-4">05/16/2023</td>
                  <td className="py-2 px-4">
                    <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded-full text-xs">Processing</span>
                  </td>
                  <td className="py-2 px-4">Boston</td>
                  <td className="py-2 px-4">
                    <Button variant="green" size="sm">
                      View
                    </Button>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          <div className="mt-4 bg-light-green rounded-md p-4">
            <h2 className="font-semibold text-dark-green mb-2">Add Verification</h2>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <div className="flex items-center space-x-2 mb-2">
                  <Check className="h-4 w-4 text-green-500" />
                  <span>Verified</span>
                </div>
                <div className="flex items-center space-x-2 mb-2">
                  <Check className="h-4 w-4 text-green-500" />
                  <span>Completed</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Check className="h-4 w-4 text-green-500" />
                  <span>Delivered</span>
                </div>
              </div>
              <div className="flex justify-end items-end">
                <Button>Add Verification</Button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-white rounded-md p-4">
          <div className="flex justify-between items-center mb-4">
            <h2 className="font-semibold text-dark-green">Member FDC</h2>
            <div className="flex space-x-2">
              <Button variant="outline" className="bg-white text-dark-green border-medium-green">
                Export to Excel
              </Button>
              <Button variant="outline" className="bg-white text-dark-green border-medium-green">
                Filter
              </Button>
              <Button variant="green">Add</Button>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="min-w-full">
              <thead>
                <tr className="bg-medium-green text-dark-green">
                  <th className="py-2 px-4 text-left">Order ID</th>
                  <th className="py-2 px-4 text-left">Status</th>
                  <th className="py-2 px-4 text-left">Distribution Center</th>
                  <th className="py-2 px-4 text-left">Quantity</th>
                </tr>
              </thead>
              <tbody>
                <tr className="border-b">
                  <td className="py-2 px-4">ORD-001</td>
                  <td className="py-2 px-4">
                    <span className="bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs">Completed</span>
                  </td>
                  <td className="py-2 px-4">Central DC</td>
                  <td className="py-2 px-4">3</td>
                </tr>
                <tr className="border-b">
                  <td className="py-2 px-4">ORD-002</td>
                  <td className="py-2 px-4">
                    <span className="bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full text-xs">Pending</span>
                  </td>
                  <td className="py-2 px-4">North DC</td>
                  <td className="py-2 px-4">2</td>
                </tr>
              </tbody>
            </table>
          </div>

          <div className="grid grid-cols-2 gap-4 mt-4">
            <div className="bg-light-green rounded-md p-4">
              <h2 className="font-semibold text-dark-green mb-2">Add Verification</h2>
              <div>
                <div className="flex items-center space-x-2 mb-2">
                  <Check className="h-4 w-4 text-green-500" />
                  <span>Verified</span>
                </div>
                <div className="flex items-center space-x-2 mb-2">
                  <Check className="h-4 w-4 text-green-500" />
                  <span>Completed</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Check className="h-4 w-4 text-green-500" />
                  <span>Delivered</span>
                </div>
                <div className="mt-2">
                  <Button size="sm">Add Verification</Button>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 gap-4">
              <div className="bg-light-green rounded-md p-4">
                <h2 className="font-semibold text-dark-green mb-2">Raise Request</h2>
                <div>
                  <div className="flex items-center space-x-2 mb-2">
                    <Check className="h-4 w-4 text-green-500" />
                    <span>Quantity</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <X className="h-4 w-4 text-red-500" />
                    <span>Remarks</span>
                  </div>
                  <div className="mt-2">
                    <Button size="sm">Raise Request</Button>
                  </div>
                </div>
              </div>

              <div className="bg-light-green rounded-md p-4">
                <h2 className="font-semibold text-dark-green mb-2">Sales Request</h2>
                <div>
                  <div className="flex items-center space-x-2 mb-2">
                    <Check className="h-4 w-4 text-green-500" />
                    <span>Quantity</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <X className="h-4 w-4 text-red-500" />
                    <span>Remarks</span>
                  </div>
                  <div className="mt-2">
                    <Button size="sm">Submit Request</Button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-md p-4">
          <div className="flex justify-between items-center mb-4">
            <h2 className="font-semibold text-dark-green">Admin</h2>
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div className="bg-light-green rounded-md p-4">
              <h2 className="font-semibold text-dark-green mb-2">Request Pending</h2>
              <div className="space-y-2">
                <div className="bg-white p-2 rounded-md">
                  <p className="text-sm font-medium">John Doe</p>
                  <p className="text-xs text-gray-600">Sales Manager</p>
                  <p className="text-xs text-gray-600">Department: Sales</p>
                  <p className="text-xs text-gray-600">Date: 12/05/2023</p>
                  <div className="flex justify-end mt-2 space-x-1">
                    <Button variant="green" size="sm" className="h-6 w-6 p-0">
                      <Check className="h-4 w-4" />
                    </Button>
                    <Button variant="destructive" size="sm" className="h-6 w-6 p-0">
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-light-green rounded-md p-4">
              <h2 className="font-semibold text-dark-green mb-2">Create/Edit Order</h2>
              <div className="space-y-2">
                <div className="bg-white p-2 rounded-md">
                  <p className="text-sm font-medium">Order #ORD-001</p>
                  <p className="text-xs text-gray-600">Customer: John Smith</p>
                  <p className="text-xs text-gray-600">Date: 05/15/2023</p>
                  <p className="text-xs text-gray-600">Status: Completed</p>
                  <div className="flex justify-end mt-2 space-x-1">
                    <Button variant="green" size="sm" className="h-6 w-6 p-0">
                      <Check className="h-4 w-4" />
                    </Button>
                    <Button variant="destructive" size="sm" className="h-6 w-6 p-0">
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-light-green rounded-md p-4">
              <h2 className="font-semibold text-dark-green mb-2">Closed Flags</h2>
              <div className="space-y-2">
                <div className="bg-white p-2 rounded-md">
                  <p className="text-sm font-medium">Issue #ISS-001</p>
                  <p className="text-xs text-gray-600">Reported by: Emily Davis</p>
                  <p className="text-xs text-gray-600">Date: 05/10/2023</p>
                  <p className="text-xs text-gray-600">Status: Resolved</p>
                  <div className="flex justify-end mt-2">
                    <Button variant="green" size="sm">
                      View
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-4">
            <h2 className="font-semibold text-dark-green mb-2">Inventory Details</h2>
            <div className="overflow-x-auto">
              <table className="min-w-full">
                <thead>
                  <tr className="bg-medium-green text-dark-green">
                    <th className="py-2 px-4 text-left">Inventory ID</th>
                    <th className="py-2 px-4 text-left">Item ID</th>
                    <th className="py-2 px-4 text-left">Total Quantity</th>
                    <th className="py-2 px-4 text-left">Remaining Quantity</th>
                    <th className="py-2 px-4 text-left">Unit Cost</th>
                    <th className="py-2 px-4 text-left">Total</th>
                  </tr>
                </thead>
                <tbody>
                  <tr className="border-b">
                    <td className="py-2 px-4">INV-001</td>
                    <td className="py-2 px-4">ITEM-001</td>
                    <td className="py-2 px-4">100</td>
                    <td className="py-2 px-4">75</td>
                    <td className="py-2 px-4">$25.99</td>
                    <td className="py-2 px-4">$2,599.00</td>
                  </tr>
                  <tr className="border-b">
                    <td className="py-2 px-4">INV-002</td>
                    <td className="py-2 px-4">ITEM-002</td>
                    <td className="py-2 px-4">50</td>
                    <td className="py-2 px-4">32</td>
                    <td className="py-2 px-4">$15.50</td>
                    <td className="py-2 px-4">$775.00</td>
                  </tr>
                  <tr className="border-b">
                    <td className="py-2 px-4">INV-003</td>
                    <td className="py-2 px-4">ITEM-003</td>
                    <td className="py-2 px-4">200</td>
                    <td className="py-2 px-4">185</td>
                    <td className="py-2 px-4">$8.75</td>
                    <td className="py-2 px-4">$1,750.00</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          <div className="mt-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-light-green rounded-md p-4">
                <h2 className="font-semibold text-dark-green mb-2">Edit Order</h2>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Check className="h-4 w-4 text-green-500" />
                    <span>Order ID: ORD-001</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Check className="h-4 w-4 text-green-500" />
                    <span>Customer: John Smith</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Check className="h-4 w-4 text-green-500" />
                    <span>Date: 05/15/2023</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Check className="h-4 w-4 text-green-500" />
                    <span>Add Field</span>
                  </div>
                  <div className="mt-2">
                    <Button size="sm">Submit Changes</Button>
                  </div>
                </div>
              </div>

              <div className="bg-light-green rounded-md p-4">
                <h2 className="font-semibold text-dark-green mb-2">Add Role</h2>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <span>Role:</span>
                    <input type="text" className="border rounded px-2 py-1 text-sm" placeholder="Enter role name" />
                  </div>
                  <div className="flex items-center space-x-2">
                    <span>Description:</span>
                    <input type="text" className="border rounded px-2 py-1 text-sm" placeholder="Enter description" />
                  </div>
                  <div className="flex items-center space-x-2">
                    <span>Permissions:</span>
                    <select className="border rounded px-2 py-1 text-sm">
                      <option>Admin</option>
                      <option>Manager</option>
                      <option>User</option>
                    </select>
                  </div>
                  <div className="mt-2">
                    <Button size="sm">Add Role</Button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

interface RequestCardProps {
  name: string
  role: string
  department: string
  date: string
  items: string[]
}

function RequestCard({ name, role, department, date, items }: RequestCardProps) {
  return (
    <div className="bg-white p-3 rounded-md">
      <p className="font-medium">{name}</p>
      <p className="text-sm text-gray-600">{role}</p>
      <p className="text-sm text-gray-600">Department: {department}</p>
      <p className="text-sm text-gray-600">Date: {date}</p>
      <div className="mt-2">
        <p className="text-sm font-medium">Items:</p>
        <ul className="text-sm text-gray-600">
          {items.map((item, index) => (
            <li key={index}>{item}</li>
          ))}
        </ul>
      </div>
    </div>
  )
}

interface OrderRowProps {
  id: string
  customer: string
  date: string
  time: string
  center: string
  city: string
  status: "completed" | "pending" | "processing"
}

function OrderRow({ id, customer, date, time, center, city, status }: OrderRowProps) {
  return (
    <tr className="border-b hover:bg-gray-50">
      <td className="py-2 px-4">{id}</td>
      <td className="py-2 px-4">{customer}</td>
      <td className="py-2 px-4">{date}</td>
      <td className="py-2 px-4">{time}</td>
      <td className="py-2 px-4">{center}</td>
      <td className="py-2 px-4">{city}</td>
    </tr>
  )
}

interface OrderDetailCardProps {
  id: string
  date: string
  time: string
  items: { name: string; quantity: number; price: string }[]
  total: string
}

function OrderDetailCard({ id, date, time, items, total }: OrderDetailCardProps) {
  return (
    <div className="bg-light-green rounded-md p-4">
      <h2 className="font-semibold text-dark-green mb-2">Order ID: {id}</h2>
      <div className="space-y-2">
        <div className="flex justify-between">
          <span className="text-sm">Order Date:</span>
          <span className="text-sm font-medium">{date}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-sm">Order Time:</span>
          <span className="text-sm font-medium">{time}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-sm">Status:</span>
          <span className="text-sm font-medium">
            <span className="bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs">Completed</span>
          </span>
        </div>
        <div className="mt-4">
          <h3 className="text-sm font-medium mb-2">Items:</h3>
          {items.map((item, index) => (
            <div key={index} className="flex justify-between mb-1">
              <span className="text-sm">
                {item.name} x{item.quantity}
              </span>
              <span className="text-sm">{item.price}</span>
            </div>
          ))}
          <div className="border-t mt-2 pt-2 flex justify-between">
            <span className="text-sm font-medium">Total:</span>
            <span className="text-sm font-medium">{total}</span>
          </div>
        </div>
      </div>
    </div>
  )
}

interface DistributionCenterCardProps {
  name: string
  location: string
  status: string
  manager: string
}

function DistributionCenterCard({ name, location, status, manager }: DistributionCenterCardProps) {
  return (
    <div className="bg-white rounded-md p-4">
      <h2 className="font-semibold text-dark-green mb-2">{name}</h2>
      <div className="space-y-2">
        <div className="flex justify-between">
          <span className="text-sm">Location:</span>
          <span className="text-sm font-medium">{location}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-sm">Status:</span>
          <span className="text-sm font-medium">
            <span className="bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs">{status}</span>
          </span>
        </div>
        <div className="flex justify-between">
          <span className="text-sm">Manager:</span>
          <span className="text-sm font-medium">{manager}</span>
        </div>
      </div>
    </div>
  )
}

interface InfoCardProps {
  label: string
  value: string
}

function InfoCard({ label, value }: InfoCardProps) {
  return (
    <div className="bg-white rounded-md p-4">
      <div className="flex justify-between">
        <span className="text-sm">{label}:</span>
        <span className="text-sm font-medium">{value}</span>
      </div>
    </div>
  )
}

