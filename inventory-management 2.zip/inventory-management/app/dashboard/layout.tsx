import type { ReactNode } from "react"
import { Search } from "lucide-react"
import { Input } from "@/components/ui/input"

interface DashboardLayoutProps {
  children: ReactNode
}

export default function DashboardLayout({ children }: DashboardLayoutProps) {
  return (
    <div className="min-h-screen bg-medium-green">
      <header className="bg-light-green py-2 px-4 flex items-center justify-between">
        <div className="flex items-center">
          <span className="text-dark-green font-semibold text-lg">Logout</span>
        </div>
        <div className="flex items-center space-x-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <Input type="search" placeholder="Search..." className="pl-9 h-8 w-48 rounded-full bg-white" />
          </div>
          <span className="text-dark-green">Invoice</span>
        </div>
      </header>

      <main className="p-4">{children}</main>
    </div>
  )
}

