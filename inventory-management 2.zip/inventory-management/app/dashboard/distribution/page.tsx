import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Search, Filter, Download, Plus, Check, Clock, X } from "lucide-react"

export default function DistributionPage() {
  // Sample distribution centers
  const distributionCenters = [
    {
      id: "DC-001",
      name: "Central Distribution Center",
      location: "Chicago, IL",
      status: "Active",
      capacity: "85%",
      orders: 156,
      manager: "John Anderson",
    },
    {
      id: "DC-002",
      name: "North Distribution Center",
      location: "Minneapolis, MN",
      status: "Active",
      capacity: "62%",
      orders: 89,
      manager: "Sarah Miller",
    },
    {
      id: "DC-003",
      name: "East Distribution Center",
      location: "Boston, MA",
      status: "Active",
      capacity: "78%",
      orders: 124,
      manager: "Robert Johnson",
    },
    {
      id: "DC-004",
      name: "West Distribution Center",
      location: "Seattle, WA",
      status: "Maintenance",
      capacity: "0%",
      orders: 0,
      manager: "Emily Wilson",
    },
    {
      id: "DC-005",
      name: "South Distribution Center",
      location: "Atlanta, GA",
      status: "Active",
      capacity: "91%",
      orders: 178,
      manager: "Michael Davis",
    },
  ]

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Distribution Centers</h1>
          <p className="text-muted-foreground">Manage distribution centers and inventory</p>
        </div>
        <Button className="md:w-auto w-full">
          <Plus className="mr-2 h-4 w-4" />
          Add Distribution Center
        </Button>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Centers</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{distributionCenters.length}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Centers</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {distributionCenters.filter((dc) => dc.status === "Active").length}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Orders</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{distributionCenters.reduce((sum, dc) => sum + dc.orders, 0)}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Avg. Capacity</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {Math.round(
                distributionCenters
                  .filter((dc) => dc.status === "Active")
                  .reduce((sum, dc) => sum + Number.parseInt(dc.capacity), 0) /
                  distributionCenters.filter((dc) => dc.status === "Active").length,
              )}
              %
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="flex flex-col md:flex-row gap-4">
        <div className="relative md:w-96 w-full">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input type="search" placeholder="Search distribution centers..." className="pl-8 w-full" />
        </div>

        <div className="flex gap-2 ml-auto">
          <Button variant="outline" size="sm">
            <Filter className="mr-2 h-4 w-4" />
            Filter
          </Button>
          <Button variant="outline" size="sm">
            <Download className="mr-2 h-4 w-4" />
            Export to Excel
          </Button>
        </div>
      </div>

      <div className="rounded-md border bg-white">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>ID</TableHead>
              <TableHead>Name</TableHead>
              <TableHead>Location</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Capacity</TableHead>
              <TableHead>Orders</TableHead>
              <TableHead>Manager</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {distributionCenters.map((dc) => (
              <TableRow key={dc.id}>
                <TableCell className="font-medium">{dc.id}</TableCell>
                <TableCell>{dc.name}</TableCell>
                <TableCell>{dc.location}</TableCell>
                <TableCell>
                  {dc.status === "Active" && (
                    <Badge variant="success" className="flex w-fit items-center gap-1">
                      <Check className="h-3 w-3" />
                      Active
                    </Badge>
                  )}
                  {dc.status === "Maintenance" && (
                    <Badge variant="warning" className="flex w-fit items-center gap-1">
                      <Clock className="h-3 w-3" />
                      Maintenance
                    </Badge>
                  )}
                </TableCell>
                <TableCell>{dc.capacity}</TableCell>
                <TableCell>{dc.orders}</TableCell>
                <TableCell>{dc.manager}</TableCell>
                <TableCell className="text-right">
                  <Button variant="ghost" size="sm">
                    View
                  </Button>
                  <Button variant="ghost" size="sm">
                    Edit
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      <div className="bg-white p-4 rounded-md border">
        <h2 className="text-lg font-semibold mb-4">Add Verification</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <p className="text-sm font-medium mb-2">Verification Items</p>
            <div className="space-y-2">
              <div className="flex items-center">
                <Check className="h-4 w-4 text-green-500 mr-2" />
                <span className="text-sm">Inventory Verified</span>
              </div>
              <div className="flex items-center">
                <Check className="h-4 w-4 text-green-500 mr-2" />
                <span className="text-sm">Safety Compliance</span>
              </div>
              <div className="flex items-center">
                <X className="h-4 w-4 text-red-500 mr-2" />
                <span className="text-sm">Quality Control</span>
              </div>
            </div>
          </div>
          <div className="flex items-end justify-end">
            <Button className="w-full md:w-auto">Add Verification</Button>
          </div>
        </div>
      </div>
    </div>
  )
}

