import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Search, Filter, Download, Plus, Check, Clock, X } from "lucide-react"

export default function OrdersPage() {
  // Sample order data
  const orders = [
    {
      id: "ORD-001",
      customer: "John Smith",
      date: "2023-05-15",
      status: "Completed",
      items: 3,
      total: "$156.99",
      distributionCenter: "Central DC",
    },
    {
      id: "ORD-002",
      customer: "Sarah Johnson",
      date: "2023-05-16",
      status: "Processing",
      items: 2,
      total: "$89.50",
      distributionCenter: "North DC",
    },
    {
      id: "ORD-003",
      customer: "Michael Brown",
      date: "2023-05-16",
      status: "Pending",
      items: 5,
      total: "$245.75",
      distributionCenter: "East DC",
    },
    {
      id: "ORD-004",
      customer: "Emily Davis",
      date: "2023-05-17",
      status: "Cancelled",
      items: 1,
      total: "$34.99",
      distributionCenter: "West DC",
    },
    {
      id: "ORD-005",
      customer: "Robert Wilson",
      date: "2023-05-17",
      status: "Completed",
      items: 4,
      total: "$178.25",
      distributionCenter: "South DC",
    },
    {
      id: "ORD-006",
      customer: "Jennifer Taylor",
      date: "2023-05-18",
      status: "Processing",
      items: 2,
      total: "$112.50",
      distributionCenter: "Central DC",
    },
  ]

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Orders</h1>
          <p className="text-muted-foreground">Manage and track all orders</p>
        </div>
        <Button className="md:w-auto w-full">
          <Plus className="mr-2 h-4 w-4" />
          New Order
        </Button>
      </div>

      <div className="flex flex-col md:flex-row gap-4">
        <div className="relative md:w-96 w-full">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input type="search" placeholder="Search orders..." className="pl-8 w-full" />
        </div>

        <div className="flex gap-2 ml-auto">
          <Button variant="outline" size="sm">
            <Filter className="mr-2 h-4 w-4" />
            Filter
          </Button>
          <Button variant="outline" size="sm">
            <Download className="mr-2 h-4 w-4" />
            Export to Excel
          </Button>
        </div>
      </div>

      <div className="rounded-md border bg-white">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Order ID</TableHead>
              <TableHead>Customer</TableHead>
              <TableHead>Date</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Items</TableHead>
              <TableHead>Total</TableHead>
              <TableHead>Distribution Center</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {orders.map((order) => (
              <TableRow key={order.id}>
                <TableCell className="font-medium">{order.id}</TableCell>
                <TableCell>{order.customer}</TableCell>
                <TableCell>{order.date}</TableCell>
                <TableCell>
                  {order.status === "Completed" && (
                    <Badge variant="success" className="flex w-fit items-center gap-1">
                      <Check className="h-3 w-3" />
                      Completed
                    </Badge>
                  )}
                  {order.status === "Processing" && (
                    <Badge variant="warning" className="flex w-fit items-center gap-1">
                      <Clock className="h-3 w-3" />
                      Processing
                    </Badge>
                  )}
                  {order.status === "Pending" && (
                    <Badge variant="secondary" className="flex w-fit items-center gap-1">
                      <Clock className="h-3 w-3" />
                      Pending
                    </Badge>
                  )}
                  {order.status === "Cancelled" && (
                    <Badge variant="destructive" className="flex w-fit items-center gap-1">
                      <X className="h-3 w-3" />
                      Cancelled
                    </Badge>
                  )}
                </TableCell>
                <TableCell>{order.items}</TableCell>
                <TableCell>{order.total}</TableCell>
                <TableCell>{order.distributionCenter}</TableCell>
                <TableCell className="text-right">
                  <Button variant="ghost" size="sm">
                    View
                  </Button>
                  <Button variant="ghost" size="sm">
                    Edit
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}

